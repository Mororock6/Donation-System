
public enum BookType {
	Education,Entertainment;
}
