public enum ClotheType {
     Shirt,Coat,Jacket,Pants,Hats,Shorts
}