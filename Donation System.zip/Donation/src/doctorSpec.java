
public enum doctorSpec {
	 Surgeon,Neorologist,Cardiologist;

}
