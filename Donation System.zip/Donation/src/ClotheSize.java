public enum ClotheSize {
   Xsmall,Small,Medium,Large,Xlarge
}