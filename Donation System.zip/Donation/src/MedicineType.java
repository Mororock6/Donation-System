public enum MedicineType {
      Antibiotics,Cream,Inhalers,Drops,Injections,Patches,Tablets;
}