
public enum WayOfDonation {
	Clothes,money,medicine,VolunteerTeacher,VolunteerDoctor,food,book;
}
