
public enum FoodType {
        Rice,Chicken,Meat,Fruits,Vegetables,Dairy,Pasta;
		
}
