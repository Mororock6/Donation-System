
public enum TeachingStages {
Primary,Secondary,University,Preparatory;
}
